<?php
// var_dump( get_template_directory_uri());
// require('./lib/page-function.php');

 get_header(); 

showMainPageContent();

 get_footer(); 
 ?>