<?php get_header(); ?>

test page

<?php get_footer(); ?>